# tvOS Launcher Lite — HY300
Launcher Android leve, escrito em Java, sem dependências de interface externas.
- Tela HOME para Android 11, controle remoto com D-pad e botão OK.
- Lista aplicativos instalados que anunciam categoria LAUNCHER.
- Fundo dinâmico com gradiente calculado por aplicativo, sem imagens ou vídeo.
- Sem rede, publicidade ou coleta de dados.

## Gerar APK no GitHub
1. Crie um repositório vazio no GitHub (público ou privado).
2. Envie **todo o conteúdo desta pasta** para a raiz do repositório, incluindo `.github/workflows/build-apk.yml`.
3. Abra **Actions** > **Compilar APK HY300** > **Run workflow** (ou faça push para `main`).
4. Após a execução, baixe o artefato `tvOS-Lite-HY300-APK`, extraia o ZIP e instale `app-debug.apk`.

O APK de teste é assinado automaticamente com chave de debug pelo processo de compilação. Não é um APK de produção.
A instalação pode exigir permitir aplicativos de fontes desconhecidas. O sistema pode exigir selecionar o launcher em Configurações > Apps padrão > Início.
Não foi compilado ou testado em um HY300 real neste ambiente.
