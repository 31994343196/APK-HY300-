package com.hy300.tvoslite;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout base;
    private TextView selectedTitle;
    private final List<View> tiles = new ArrayList<>();
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    private void background(String key) {
        int hue = Math.floorMod(key.hashCode(), 360);
        float[] hsv = {hue, .48f, .25f};
        int first = Color.HSVToColor(hsv);
        hsv[0] = (hue + 38) % 360; hsv[1] = .50f; hsv[2] = .09f;
        int second = Color.HSVToColor(hsv);
        base.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{first, second, Color.rgb(8, 11, 20)}));
    }
    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    @Override public void onCreate(Bundle state) { super.onCreate(state); render(); }
    @Override protected void onResume() { super.onResume(); }
    private void render() {
        tiles.clear();
        base = new LinearLayout(this); base.setOrientation(LinearLayout.VERTICAL);
        base.setPadding(dp(38), dp(25), dp(38), dp(18));
        background("tvOS Lite");
        setContentView(base);
        TextView title = text("tvOS  Lite", 25, true);
        base.addView(title, new LinearLayout.LayoutParams(-1, dp(46)));
        selectedTitle = text("Escolha um aplicativo", 17, false);
        LinearLayout.LayoutParams desc = new LinearLayout.LayoutParams(-1, dp(48));
        desc.bottomMargin=dp(12); base.addView(selectedTitle, desc);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        base.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        GridLayout grid = new GridLayout(this); grid.setColumnCount(4);
        scroll.addView(grid);
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = new ArrayList<>(pm.queryIntentActivities(launcher, 0));
        Collections.sort(apps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(pm).toString(), b.loadLabel(pm).toString());
            }
        });
        for (ResolveInfo app : apps) {
            if (app.activityInfo == null || getPackageName().equals(app.activityInfo.packageName)) continue;
            String label = app.loadLabel(pm).toString();
            LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER); tile.setFocusable(true); tile.setClickable(true);
            tile.setBackground(shape(0x442A3246, 16));
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width=dp(145); gp.height=dp(114); gp.setMargins(dp(7),dp(7),dp(7),dp(7));
            grid.addView(tile,gp);
            ImageView icon = new ImageView(this);
            try { Drawable d = app.loadIcon(pm); icon.setImageDrawable(d); } catch (Exception ignored) {}
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(52),dp(52));
            ip.bottomMargin=dp(9); tile.addView(icon,ip);
            TextView name = text(label,12,false); name.setGravity(Gravity.CENTER);
            name.setSingleLine(true); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            tile.addView(name,new LinearLayout.LayoutParams(dp(125),dp(24)));
            tile.setOnFocusChangeListener((v, focused) -> {
                if(focused) {
                    selectedTitle.setText(label);
                    background(app.activityInfo.packageName);
                    tile.setBackground(shape(0x995E7396,16));
                    tile.setScaleX(1.06f); tile.setScaleY(1.06f);
                } else {
                    tile.setBackground(shape(0x442A3246,16));
                    tile.setScaleX(1f); tile.setScaleY(1f);
                }
            });
            tile.setOnClickListener(v -> {
                Intent i = new Intent();
                i.setClassName(app.activityInfo.packageName,app.activityInfo.name);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(i); } catch (Exception e) {
                    selectedTitle.setText("Não foi possível abrir " + label);
                }
            });
            tiles.add(tile);
        }
        if(tiles.isEmpty()) {
            selectedTitle.setText("Nenhum aplicativo encontrado");
        } else {
            tiles.get(0).requestFocus();
        }
    }
}
